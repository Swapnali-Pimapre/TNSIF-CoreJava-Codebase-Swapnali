
        // DOM Elements
        const navLinks = document.querySelector('.nav-links');
        const hamburger = document.querySelector('.hamburger');
        const contactForm = document.getElementById('contactForm');
        const counterEl = document.getElementById('counter');
        const header = document.getElementById('header');

        // Mobile Menu Toggle
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('fa-times');
        });

        // Close mobile menu when clicking on links
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                hamburger.classList.remove('fa-times');
            });
        });

        // Header scroll effect
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                header.style.boxShadow = '0 5px 20px rgba(122, 122, 138, 0.1)';
            } else {
                header.style.boxShadow = 'none';
            }
        });

        // Visitor Counter
        function updateCounter() {
            let count = localStorage.getItem('visitorCount');
            if (!count) {
                count = 0;
            }
            count = parseInt(count) + 1;
            localStorage.setItem('visitorCount', count);
            counterEl.textContent = count;
        }

        // Form Validation
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailPattern.test(email)) {
                alert('Please enter a valid email address.');
                return;
            }
            
            // Form is valid
            alert('Thank you for your message! I will get back to you soon.');
            contactForm.reset();
        });

        // Smooth Scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    window.scrollTo({
                        top: target.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Active link on scroll
        window.addEventListener('scroll', () => {
            const sections = document.querySelectorAll('section');
            const navLi = document.querySelectorAll('.nav-links li a');
            
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (pageYOffset >= (sectionTop - 100)) {
                    current = section.getAttribute('id');
                }
            });
            
            navLi.forEach(li => {
                li.classList.remove('active');
                if (li.getAttribute('href') === `#${current}`) {
                    li.classList.add('active');
                }
            });
        });

        // Initialize counter
        updateCounter();

        // Animate elements when they come into view
        const animateOnScroll = () => {
            const elements = document.querySelectorAll('.skill-category, .experience-item, .project-card, .education-item, .cert-card');
            
            elements.forEach(el => {
                const rect = el.getBoundingClientRect();
                if (rect.top < window.innerHeight && rect.bottom >= 0) {
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }
            });
        }

        // Set initial state
        document.querySelectorAll('.skill-category, .experience-item, .project-card, .education-item, .cert-card').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'all 0.6s ease';
        });

        // Initial check
        animateOnScroll();
        
        // Check on scroll
        window.addEventListener('scroll', animateOnScroll);
